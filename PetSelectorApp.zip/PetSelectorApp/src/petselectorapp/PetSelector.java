/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package petselectorapp;

/**
 *
 * @author victorotienoobuwa
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PetSelector extends JFrame {
    
    private JRadioButton birdButton, catButton, dogButton, rabbitButton, pigButton;
    private JLabel imageLabel;
    private ImageIcon birdIcon, catIcon, dogIcon, rabbitIcon, pigIcon;

    public PetSelector() {
        // Set the window title
        setTitle("Pet Selector");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create radio buttons for pets
        birdButton = new JRadioButton("Bird");
        catButton = new JRadioButton("Cat");
        dogButton = new JRadioButton("Dog");
        rabbitButton = new JRadioButton("Rabbit");
        pigButton = new JRadioButton("Pig");

        // Add radio buttons to a button group
        ButtonGroup group = new ButtonGroup();
        group.add(birdButton);
        group.add(catButton);
        group.add(dogButton);
        group.add(rabbitButton);
        group.add(pigButton);

        // Add an action listener to each radio button
        birdButton.addActionListener(new PetSelectionHandler());
        catButton.addActionListener(new PetSelectionHandler());
        dogButton.addActionListener(new PetSelectionHandler());
        rabbitButton.addActionListener(new PetSelectionHandler());
        pigButton.addActionListener(new PetSelectionHandler());

        // Create a panel for the radio buttons
        JPanel radioPanel = new JPanel();
        radioPanel.setLayout(new GridLayout(5, 1));
        radioPanel.add(birdButton);
        radioPanel.add(catButton);
        radioPanel.add(dogButton);
        radioPanel.add(rabbitButton);
        radioPanel.add(pigButton);

        // Load pet images from the 'images' folder inside 'src'
birdIcon = new ImageIcon(getClass().getResource("/images/bird.png"));
catIcon = new ImageIcon(getClass().getResource("/images/cat.png"));
dogIcon = new ImageIcon(getClass().getResource("/images/dog.png"));
rabbitIcon = new ImageIcon(getClass().getResource("/images/rabbit.png"));
pigIcon = new ImageIcon(getClass().getResource("/images/pig.png"));


        // Create a label to display the pet image
        imageLabel = new JLabel();
        imageLabel.setHorizontalAlignment(JLabel.CENTER);

        // Add components to the frame
        add(radioPanel, BorderLayout.WEST);
        add(imageLabel, BorderLayout.CENTER);
    }

    // Inner class to handle radio button selection
    private class PetSelectionHandler implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            JRadioButton selectedButton = (JRadioButton) e.getSource();
            String petName = selectedButton.getText();
            ImageIcon petImage = null;

            switch (petName) {
                case "Bird":
                    petImage = birdIcon;
                    break;
                case "Cat":
                    petImage = catIcon;
                    break;
                case "Dog":
                    petImage = dogIcon;
                    break;
                case "Rabbit":
                    petImage = rabbitIcon;
                    break;
                case "Pig":
                    petImage = pigIcon;
                    break;
            }

            // Set the image on the label
            imageLabel.setIcon(petImage);

            // Show message dialog with selected pet
            JOptionPane.showMessageDialog(null, "You selected: " + petName);
        }
    }

    public static void main(String[] args) {
        // Create and show the GUI
        SwingUtilities.invokeLater(() -> {
            PetSelector frame = new PetSelector();
            frame.setVisible(true);
        });
    }
}

